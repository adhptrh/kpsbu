<script>
	$(document).ready(function() {
		$("#notif").fadeTo(2000, 500).slideUp(500, function(){
			$("#notif").slideUp(500);
		});
	})
</script>