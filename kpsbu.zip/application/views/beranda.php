<html>
	<head>
		<title>Welcome</title>
	</head>
		<div class="x_panel">
			<center><h3>Welcome</h3></center>
	</body>
	</html>